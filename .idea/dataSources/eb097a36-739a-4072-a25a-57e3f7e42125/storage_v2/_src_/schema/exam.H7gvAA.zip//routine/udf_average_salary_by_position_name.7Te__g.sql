create
    definer = root@localhost function udf_average_salary_by_position_name(name varchar(40)) returns float deterministic
BEGIN
return(
	SELECT AVG (salary)
    FROM positions p 
    JOIN workers w ON position_id = p.id
    WHERE p.name = name
    GROUP BY p.name);
END;

