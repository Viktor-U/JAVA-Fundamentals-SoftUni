create
    definer = root@localhost procedure udp_increase_salaries_by_country(IN country_name varchar(40))
BEGIN
	SELECT first_name, last_name, '->' as '->', salary AS 'salary before', FORMAT(salary * 1.05, 2) AS 'salary after'
    FROM workers w
    JOIN preserves p ON w.preserve_id = p.id
    JOIN countries_preserves cp ON cp.preserve_id = p.id
    JOIN countries c ON cp.country_id = c.id
    WHERE c.name = country_name;
    
    UPDATE workers w
    JOIN preserves p ON w.preserve_id = p.id
    JOIN countries_preserves cp ON cp.preserve_id = p.id
    JOIN countries c ON cp.country_id = c.id
    SET salary = salary * 1.05
    WHERE c.name = country_name;
END;

